package com.wiley.javainterviewsexposed.appendix

object RunWithApp extends App {
  val pi = 3.14
  val radius = 200

  val area = pi * radius * radius

  println(s"The area of the circle is: $area")
}
