package com.wiley.javainterviewsexposed.chapter16;

public interface Dictionary {

    boolean validWord(String word);

}

