package com.wiley.javainterviewsexposed.chapter16;

public class ServerSetup {

    public ServerSetup(String property) {
        System.out.println(property);
    }
}
