package com.wiley.javainterviewsexposed.chapter19;

public class MainClass {

    public static void main(String[] args) {
        System.out.println("This is the main class with args: ");
        for (String arg : args) {
            System.out.println("  " + arg);
        }
    }
}
