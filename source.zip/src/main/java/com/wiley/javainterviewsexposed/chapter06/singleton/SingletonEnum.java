package com.wiley.javainterviewsexposed.chapter06.singleton;

public enum SingletonEnum {
    INSTANCE;

    public void singletonMethod() {
        // operations here
    }
}
