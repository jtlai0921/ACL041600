package com.wiley.javainterviewsexposed.chapter07;

public interface IntegerOperation {
    Integer performOperation(Integer value);
}
