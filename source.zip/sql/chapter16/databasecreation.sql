CREATE TABLE USER (
  id INT,
  username VARCHAR(100)
);