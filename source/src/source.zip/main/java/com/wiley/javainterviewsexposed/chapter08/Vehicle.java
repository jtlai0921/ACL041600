package com.wiley.javainterviewsexposed.chapter08;

public class Vehicle {

    public String getName() {
        return "GENERIC VEHICLE";
    }
}

class Car extends Vehicle {

    public String getname() {
        return "CAR";
    }
}