package com.wiley.javainterviewsexposed.chapter06.template;

public interface StackPredicate {
    boolean isValid(int i);
}
