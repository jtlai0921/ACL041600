package com.wiley.javainterviewsexposed.chapter08;

public class Square extends Rectangle {

    public Square(final int sideLength) {
        super(sideLength, sideLength);
    }
}
