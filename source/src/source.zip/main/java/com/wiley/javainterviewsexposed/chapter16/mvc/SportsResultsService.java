package com.wiley.javainterviewsexposed.chapter16.mvc;

import java.util.List;

public interface SportsResultsService {
    List<Result> getMostRecentResults();
}
