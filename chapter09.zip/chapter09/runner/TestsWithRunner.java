package com.wiley.javainterviewsexposed.chapter09.runner;

import org.junit.Test;

//@RunWith(RandomizedRunner.class)
public class TestsWithRunner {

    @Test
    public void method1() {
    }

    @Test
    public void method2() {
    }

    @Test
    public void method3() throws Exception {
        throw new Exception();
    }

    @Test
    public void method4() {
    }

    @Test
    public void method5() {
    }

    @Test
    public void method6() {
    }

}

