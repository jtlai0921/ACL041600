Contains the Android code for chapter 20.

Author: Greg Milette
gregorym@gmail.com

Code listing to file mapping

20-01: com.wiley.acinginterview.recipe.RecipeList
20-02: com.wiley.acinginterview.recipe.RecipeDetail
20-03: com.wiley.acinginterview.share.ShareIntentSender
20-04: AndroidManifest.xml
20-05: com.wiley.acinginterview.recipe.RecipeList
20-06: AndroidManifest.xml
20-07: com.wiley.acinginterview.receiver.NetworkBroadcastReceiver
20-08: com.wiley.acinginterview.service.RecipeBackupService
20-09: AndroidManifest.xml
20-10: com.wiley.acinginterview.service.CookingChatService

20-11: com.wiley.acinginterview.service.CookingChatLauncher
20-12: res/layout/frontof.xml
20-13: res/layout/button_on_bottom.xml
20-14: res/layout/side_by_side.xml
20-15: res/layout/recipe_detail.xml
20-16: com.wiley.acinginterview.recipe.frag.RecipeViewAsFragments 
20-17: com.wiley.acinginterview.recipe.frag.RecipeListFragment
20-18: com.wiley.acinginterview.recipe.frag.RecipeActions
20-19: com.wiley.acinginterview.test.SharedPreferenceTester (in InterviewBookTest) 
20-20: com.wiley.acinginterview.db.DatabaseHelperBlank
20-21: com.wiley.acinginterview.db.DatabaseHelper
20-22: com.wiley.acinginterview.db.DatabaseHelper
20-23: com.wiley.acinginterview.test.FilesTest (in InterviewBookTest) 
20-24: com.wiley.acinginterview.location.LocationActivity
