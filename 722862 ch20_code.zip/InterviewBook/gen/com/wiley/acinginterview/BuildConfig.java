/** Automatically generated file. DO NOT MODIFY */
package com.wiley.acinginterview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}