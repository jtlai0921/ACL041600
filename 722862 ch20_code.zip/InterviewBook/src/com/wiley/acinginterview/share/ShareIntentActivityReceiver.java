package com.wiley.acinginterview.share;

import android.app.Activity;
import android.os.Bundle;

/**
 * gets called when a user sends the share Intent to this
 */
public class ShareIntentActivityReceiver extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //TODO: handle the share intent here
    }
}
