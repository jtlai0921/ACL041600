package com.wiley.acinginterview.recipe.frag;

public interface RecipeActions
{
    public void showRecipe(String recipeId);
}
