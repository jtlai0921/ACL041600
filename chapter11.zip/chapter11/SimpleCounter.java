package com.wiley.javainterviewsexposed.chapter11;

public class SimpleCounter {

    private int number = 0;

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }
}