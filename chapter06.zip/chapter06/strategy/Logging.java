package com.wiley.javainterviewsexposed.chapter06.strategy;

public interface Logging {
    void write(String message);
}
